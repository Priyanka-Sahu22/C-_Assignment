﻿using System;

namespace PatientAppointmentManagementSystem
{
   public class PatientRegistration
    {
        #region patient information fields
        private string _patientFirstname;
        private string _patientLastname;
        private string _patientID;
        private int _patientAge;
        private int _patientWeight;
        private string _patientGender;
        private string _phoneNumber;
        private static int startID = 0;
        #endregion

       public  PatientRegistration()
        {
            startID = startID + 1;
            this._patientID = startID + "";
              
        }
        #region Using properties to get and set the patient information.

        public string PatientFirstname
        {
            get { return this._patientFirstname; }
            set { this._patientFirstname = value;}
        }
        public string PatientLastname
        {
            get { return this._patientLastname; }
            set { this._patientLastname = value; }
        }
        public string PatientID
        {
            get { return this._patientID; }
            
        }
        public int PatientAge
        {
            get { return this._patientAge; }
            set { this._patientAge = value; }
        }
        public int PatientWeight
        {
            get { return this._patientWeight; }
            set { this._patientWeight = value; }
        }
        public string PatientGender
        {
            get { return this._patientGender; }
            set { this._patientGender = value; }
        }
        public string patientPhone
        {
            get { return this._phoneNumber; }
            set { this._phoneNumber = value; }
        }
        #endregion
    }
}
