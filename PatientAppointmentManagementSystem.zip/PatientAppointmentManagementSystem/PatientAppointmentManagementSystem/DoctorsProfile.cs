﻿using System;

namespace PatientAppointmentManagementSystem
{
    public class DoctorsProfile
    {
        private string _doctorName;
        private int _doctorID;
        private string docDepartment;
        private string _phoneNumber;

        public DoctorsProfile(string docName, int docID, string docDep, string contactNumber)
        {
            this._doctorName = docName;
            this._doctorID = docID;
            this.docDepartment = docDep;
            this._phoneNumber = contactNumber;
        }

        public string doctorName
        {
            get{ return this._doctorName;}
         
        }
        public int doctorID
        {
            get { return this._doctorID; }

        }
        public string docDepart
        {
            get { return this.docDepartment; }

        }

        public string docNumber
        {
            get { return this._phoneNumber; }

        }

    }

}
