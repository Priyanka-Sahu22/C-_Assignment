﻿using System;
using System.Collections.Generic;


namespace PatientAppointmentManagementSystem
{
    public class StoreAppointment
    {
        private static Dictionary<int, Appointment> dict = new Dictionary<int, Appointment>();

        public static int AddAppointment(Appointment A)
        {

            dict.Add(A.appoinmentID, A);
            Console.WriteLine("Adding appointment with ID=" + A.appoinmentID);
            Console.WriteLine("Sending message to doctor: " + A.doctorDetails.doctorID);
            Console.WriteLine("Sending message to patient: " + A.patientDetails.PatientID);
            return A.appoinmentID;

        }
        public static Appointment GetAppointment(int appointnmentID)
        {
            return dict[appointnmentID];
        }

        public static void PrintAppointDetails()
        {
            foreach (KeyValuePair<int, Appointment> item in dict)
            {
                Console.WriteLine("Appointment ID {0}, Doctor Name: {1} Patient Name: {2}", item.Key, item.Value.doctorDetails.doctorName, item.Value.patientDetails.PatientFirstname);
            }
        }

        public static void DelAppointment(int appointmentID)
        {
            if (dict.ContainsKey(appointmentID))
            {
                dict.Remove(appointmentID);
                Console.WriteLine("Appointment is deleted successfully");
            }

            else
            {
                Console.WriteLine("Appointment ID doesnot exist");
            }


        }


    }
}
