﻿using System;
using System.Collections.Generic;


namespace PatientAppointmentManagementSystem
{
    public class StorePatient
    {
        private static Dictionary<string, PatientRegistration> dict = new Dictionary<string, PatientRegistration>();

        public static string AddPatient(PatientRegistration P)
        {
            dict.Add(P.PatientID, P);
            Console.WriteLine("Adding Patient with ID=" + P.PatientID);
            return P.PatientID;

        }

        public static PatientRegistration GetPatient(string patientID)
        {
            return dict[patientID];

        }
        public static bool isValidPatientId(string patientID)
        {
            return dict.ContainsKey(patientID);

        }

        public static bool isEmpty()
        {
            int keyNumber = dict.Count;
            if (keyNumber == 0)
            {
                return true;
            }
            else return false;
        }
    }
}
