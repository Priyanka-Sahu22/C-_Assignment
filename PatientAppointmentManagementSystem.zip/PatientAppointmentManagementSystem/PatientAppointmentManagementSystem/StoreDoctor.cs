﻿using System;
using System.Collections.Generic;

namespace PatientAppointmentManagementSystem
{
    
        public class StoreDoctor
        {
            private static Dictionary<int, DoctorsProfile> dict = new Dictionary<int, DoctorsProfile>();

            static StoreDoctor()
            {
                DoctorsProfile doc1 = new DoctorsProfile(" Dr.Ramchandran", 1, "Neurologist", "9900332211");

                DoctorsProfile doc2 = new DoctorsProfile(" Dr.Govind", 2, "Cardiologist", "9988776655");

                AddDoctor(doc1);
                AddDoctor(doc2);

            }

            public static int AddDoctor(DoctorsProfile D)
            {
                dict.Add(D.doctorID, D);
                Console.WriteLine("Adding Doctor with ID=" + D.doctorID);
                return D.doctorID;

            }
            public static DoctorsProfile GetDoctor(int doctorID)
            {
                return dict[doctorID];
            }

            public static bool isValidDoctorId(int doctorID)
            {
                return dict.ContainsKey(doctorID);

            }
            public static void PrintDoctorDetails()
            {
            foreach (KeyValuePair<int, DoctorsProfile> item in dict)
            {
                Console.WriteLine(" Doctor ID: {0} Doctor name: {1} Doctor Speciality: {2} Doctor ContactNumber {3}", item.Key, item.Value.doctorName,item.Value.docDepart,item.Value.docNumber);
            }
        }

    }
    }

