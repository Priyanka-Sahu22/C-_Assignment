﻿using System;
using System.Collections.Generic;


namespace PatientAppointmentManagementSystem
{
   public class Program
    {
        static void Main(string[] args)
        {
            string task = "";
            while (task!="6")
            {
                Console.WriteLine("----------------------------------------");
                Console.WriteLine("Please Enter the Task to be performed");
                Console.WriteLine("Press 1 to add patient details");
                Console.WriteLine("Press 2 to print Doctor details");
                Console.WriteLine("Press 3 to schedule an appointment"); 
                Console.WriteLine("Press 4 to print all appointment");
                Console.WriteLine("Press 5 to delete an appointment");
                Console.WriteLine("Press 6 to exit from the application");
                Console.WriteLine("----------------------------------------");

                task = Console.ReadLine();
                if (task == "1")
                {
                    Console.WriteLine("Do you want to enter the patient details,press Y to register the patient details");
                    string addPatient = Console.ReadLine();
                    while (string.Compare(addPatient, "Y",true)==0)
                    {
                        Program.AddPatient();
                        Console.WriteLine("Press Y to add more patient");
                        addPatient = Console.ReadLine();

                    }

                    continue;
                }

                if (task == "2")
                {

                    StoreDoctor.PrintDoctorDetails();
                    continue;
                }

                if (task == "3")
                {
                        Console.WriteLine("Do you want to create an appointment? press Y to  create an appointment");
                        string addAppointment = Console.ReadLine();
                        while (string.Compare(addAppointment, "Y", true) == 0)
                        {
                            CreateAppointment();
                            Console.WriteLine("Press Y to add more appointment");
                            addAppointment = Console.ReadLine();
                        }
                    

                    continue;
                }

                if (task == "4") 
                {
                
                   StoreAppointment.PrintAppointDetails();
                   continue;
                }

                if (task == "5")
                {
                    Console.WriteLine("Enter Appointment ID to be deleted");
                    int appID = int.Parse(Console.ReadLine());
                    StoreAppointment.DelAppointment(appID);
                    continue;
                }

            }


        }
        

        static void AddPatient() {

                Console.WriteLine("Patient First Name:");
                string firstName = Console.ReadLine();
                Console.WriteLine("Patient Last Name:");
                string lastName = Console.ReadLine();
                Console.WriteLine("Patient Age:");
                int age = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Patient Weight:");
                int weight = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Patient Gender:");
                string gender = Console.ReadLine();
                Console.WriteLine("Patient PhoneNumber:");
                string phoneNumber = Console.ReadLine();

                PatientRegistration patientInformationObj = new PatientRegistration();

                patientInformationObj.PatientFirstname = firstName;
                patientInformationObj.PatientLastname = lastName;
                patientInformationObj.PatientAge = age;
                patientInformationObj.PatientWeight = weight;
                patientInformationObj.PatientGender = gender;

                StorePatient.AddPatient(patientInformationObj);
            
        }
        static void CreateAppointment()
        {
            
                Console.WriteLine("Enter Patient ID:");
                string patientID = Console.ReadLine();
                Console.WriteLine("Enter Doctor ID:");
                int doctorID = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Time:");
                string Time = Console.ReadLine();  
            if (StorePatient.isEmpty())
            {
                Console.WriteLine("Paient Store is Empty!! Required registration "); 
            }

           else if (StorePatient.isValidPatientId(patientID))
            {
                if (StoreDoctor.isValidDoctorId(doctorID))
                {
                    Appointment AP = new Appointment(StorePatient.GetPatient(patientID), StoreDoctor.GetDoctor(doctorID), Time);
                    StoreAppointment.AddAppointment(AP);
                }
                else
                {
                    Console.WriteLine("Invalid doctor ID entered");

                }

             }
            else {
                Console.WriteLine("Invalid patient ID entered");

                 }      


        }
       

    }

    
}


