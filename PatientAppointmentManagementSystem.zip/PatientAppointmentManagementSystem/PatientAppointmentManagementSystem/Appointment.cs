﻿using System;

namespace PatientAppointmentManagementSystem
{
   public class Appointment
    {
        private PatientRegistration patient;
        private DoctorsProfile doctor;
        private int _appointmentID;
        private string time;
        private static int startID=0;

        public Appointment(PatientRegistration patient, DoctorsProfile doctor, string time)
        {
            this.patient = patient;
            this.doctor = doctor;
            this.time = time;
            startID = startID + 1;
            this._appointmentID = startID;
        }

        public PatientRegistration patientDetails
        {
            get { return this.patient; }
        }
        public DoctorsProfile doctorDetails
        {
            get { return this.doctor; }
        }
        public string timeDetails
        {
            get { return this.time; }
        }
        public int appoinmentID
        {
            get { return this._appointmentID; }
        }
    }
}
